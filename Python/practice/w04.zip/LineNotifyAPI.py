import requests

myToken = "E5sHc1czNqUzhK8UrDiLhudO9evRY44D7EydROb0HZp"

def lineNotify(token=myToken, msg='', picURI=''):
    url = "https://notify-api.line.me/api/notify"
    headers = {
                "Authorization": "Bearer " + token,
                #"Content-Type" : "application/x-www-form-urlencoded"
    }
    payload = {'message': msg}
    if picURI:
        files = {'imageFile': open(picURI, 'rb')}
        r = requests.post(url, headers=headers, params=payload, files=files)
    else:
        r = requests.post(url, headers = headers, params = payload)
    return r.status_code


if __name__=='__main__':
    msg = "今天天氣真好"
    picURI = "./5Pikachu.png"

    lineNotify(myToken, msg, picURI)
