import requests
from bs4 import BeautifulSoup

url = 'https://jgirl.ddns.net/WebPages/%E9%95%B7%E6%81%A8%E6%AD%8C.htm'

r = requests.get(url)
soup = BeautifulSoup(r.text,'html5lib')
lines = soup.find_all(class_='MsoNormal')

s=''
for line in lines:
    s += line.text + '\n'

print(s)
