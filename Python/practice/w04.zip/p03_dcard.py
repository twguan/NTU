import requests
from bs4 import BeautifulSoup

import LineNotifyAPI as LN

url = 'https://www.dcard.tw/f'

r = requests.get(url)
soup = BeautifulSoup(r.text,'html5lib')
lines = soup.find_all(class_='tgn9uw-3')

s=''
for line in lines:
    s += line.text.strip() + '\n'
    s += line['href'] + '\n\n'
    LN.lineNotify(msg = line.text.strip())

print(s)

with open('dcard.txt','w',encoding='utf-8') as f:
    f.write(s)

