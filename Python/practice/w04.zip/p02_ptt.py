import requests
from bs4 import BeautifulSoup

url = 'https://www.ptt.cc/bbs/Stock/index.html'

r = requests.get(url)
soup = BeautifulSoup(r.text,'html5lib')
lines = soup.find_all(class_='title')

s=''
for line in lines:
    s += line.text.strip() + '\n'

print(s)

with open('ptt.txt','w',encoding='utf-8') as f:
    f.write(s)
