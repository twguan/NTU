# 後測測資配分
* 0.in(20%): 前測測資有跟上
* 1.in(10%): addMember + borrowBook(僅有會員，無異常狀況)
* 2.in(10%): addMember + borrowBook(有非會員，會員借書正常)
* 3.in(10%): addMember + borrowBook(有非會員，書借完)
* 4.in(10%): addMember + borrowBook(全功能)
* 5.in(10%): addMember + borrowBook(僅有會員，無異常狀況) + retuenBook(僅會員)
* 6.in(30%): No other constrain